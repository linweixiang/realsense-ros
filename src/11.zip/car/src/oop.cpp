#include <ros/ros.h>

#include <iostream>

#include "car_status.h"

using namespace ros;

using namespace std;
int main(int argc, char** argv)
{
  cout <<"hello world" <<endl;
}
